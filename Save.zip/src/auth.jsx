export var user = localStorage.getItem(":user:")
export var password = localStorage.getItem(":password:")

if (!user || !password) {
    auth()
}
else {
    checkAuth()
}

async function auth() {
    var res = await fetch(api + "/user/create");
    if (!res.ok) window.location.reload();
    var data = await res.json();
    if (data.err) window.location.reload();
    log(data);
    user = data.user;
    password = data.password;
    localStorage.setItem(":user:", user)
    localStorage.setItem(":password:", password)
}

async function checkAuth() {
    var url = new URL(api + "/isauth")
    url.searchParams.set("u", user)
    url.searchParams.set("p", password)
    var res = await fetch(url);
    if (!res.ok) window.location.reload();
    var isAuth = await res.json();
    if (!isAuth) {
        localStorage.removeItem(":user:")
        window.location.reload()
    };
}