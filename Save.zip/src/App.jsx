import { useEffect, useState } from 'react'
import { Home } from "./comp/home/index.jsx"
import { Contacts } from "./comp/contacts/index.jsx"
import { Edit } from "./comp/edit/index.jsx"
import { Search } from "./comp/search/index.jsx"
import { Menu } from "./comp/menu/index.jsx"


export var url = new URL(document.location)
export var _page = url.searchParams.get("page") || localStorage.getItem(":page:") || "home"

history.replaceState("", "", "/openContacts");

export default function App() {

  const [page, setPage] = useState(_page)

  useEffect(() => {
    _page = page;
    localStorage.setItem(":page:", page);
  }, [page])

  return (
    <>

      <div className={page == "home" ? "" : "none"}>
        <Home page={page} setPage={setPage} />
      </div>

      <div className={page == "contacts" ? "page" : "none"}>
        <Contacts page={page} setPage={setPage} />
      </div>

      <div className={page == "search" ? "page" : "none"}>
        <Search page={page} setPage={setPage} />
      </div>

      <div className={page == "edit" ? "page" : "none"}>
        <Edit page={page} setPage={setPage} />
      </div>

      <Menu page={page} setPage={setPage} />

    </>
  )
}