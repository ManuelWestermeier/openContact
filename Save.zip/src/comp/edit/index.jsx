import { useEffect, useRef, useState } from "react";
import { password, user } from "../../auth"
import "./index.css"
import LoadingSpinner from "../loading-spinner/index"

export function Edit({ }) {

    const nameInput = useRef()
    const mailInput = useRef()
    const telInput = useRef()
    const websideInput = useRef()
    const descrInput = useRef()

    const [userData, setUserData] = useState({
        mail: "mail",
        tel: "telephone",
        webside: "website",
        desc: "description",
    })

    const [name, setName] = useState("loading")

    const [err, setError] = useState("")

    useEffect(() => {

        getUserData(user, setUserData)

        if (name != "loading") return;

        (async () => {
            var res = await fetch(api + "/name/" + user)
            var name = await res.text()
            setName(name)
        })()

    }, [])

    return <>

        <center className="edit">
            <h1>Profile</h1>
            <a target="_blank" href={getAddLink(user)}><button>Open Your Contact</button></a>
            <button onClick={e => share(user)}>Share Your Contact</button>
            <form onSubmit={async e => {

                e.preventDefault();

                var url = new URL(api + "/user/update")

                url.searchParams.set("data", JSON.stringify({
                    user,
                    password,
                    name: nameInput.current.value,
                    mail: mailInput.current.value,
                    tel: telInput.current.value,
                    webside: websideInput.current.value,
                    desc: descrInput.current.value,
                }))

                var res = await fetch(url)

                if (!res.ok) return

                var data = await res.json()

                if (data === false) setError("Not Update Please Retry")
                if (data === true) setError("Up To Date")

            }}>
                {
                    name == "loading" ? <LoadingSpinner /> :
                        <>
                            <input defaultValue={name} type="text" placeholder="name..." ref={nameInput} />
                            <br />
                            <input defaultValue={userData.mail} type="mail" placeholder="mail..." ref={mailInput} />
                            <br />
                            <input defaultValue={userData.tel} type="tel" placeholder="telephone..." ref={telInput} />
                            <br />
                            <input defaultValue={userData.webside} type="url" placeholder="website..." ref={websideInput} />
                            <br />
                            <textarea defaultValue={userData.desc} type="text" placeholder="description..." ref={descrInput} />
                            <br />
                            <button>Post</button>
                        </>
                }
            </form>
            <p style={{ color: "red" }}>{err}</p>
        </center>

    </>

}

async function getUserData(cont, setData) {

    try {
        var url = api + "/userdata/" + cont;
        var data = await fetch(url);
        if (!data.ok) return console.error("Not Load");
        var json = await data.json();
        if (typeof json == "object")
            setData(json)

    } catch (err) {
        console.error(err);
    }

}

var share = cont => {
    var url = new URL(document.location.origin + "/openContacts");
    url.searchParams.set("run", "newContact");
    url.searchParams.set("user", cont);
    url.searchParams.set("page", "contacts");
    try {
        navigator.share({
            title: cont,
            url: url.toString(),
        })
    } catch (error) {
        var whatsAppURL = new URL("https://api.whatsapp.com/send")
        whatsAppURL.searchParams.set("text", url);
        try {
            window.open(whatsAppURL)
        } catch (error) {
            var a = document.createElement("a")
            a.href = whatsAppURL.toString()
            a.target = "_blank"
            a.click()
        }
    }
}

function getAddLink(user) {
    var url = new URL(document.location.origin + "/openContacts");
    url.searchParams.set("run", "newContact");
    url.searchParams.set("user", user);
    url.searchParams.set("page", "contacts");
    return url.toString()
}