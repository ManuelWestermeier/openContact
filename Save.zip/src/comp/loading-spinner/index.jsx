import "./index.css"

export default function LoadingSpinner() {
    return <>
        <div className="loading-spinner">
            <h1>Loading...</h1>
        </div>
    </>
}