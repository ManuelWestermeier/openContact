export default function User({ name, see, contactName }) {

    return <a style={{ display: !see ? "none" : "" }} href={getAddLink(name)}>
        <li>
            {contactName}
        </li>
    </a>

}

function getAddLink(user) {
    var url = new URL(document.location.origin + "/openContacts");
    url.searchParams.set("run", "newContact");
    url.searchParams.set("user", user);
    url.searchParams.set("page", "contacts");
    return url.toString()
}