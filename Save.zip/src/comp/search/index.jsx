import { useEffect, useRef, useState } from "react"
import "./index.css"
import User from "./user"
import LoadingSpinner from "../loading-spinner"

var userNames = {}

export function Search({ }) {

    var [contacts, setContacts] = useState([])
    var [contactNames, setContactNames] = useState(contacts)
    var [see, setSee] = useState([])
    var [noResults, setNoResults] = useState(false)
    var [loading, setLoading] = useState(false)

    var inp = useRef()

    useEffect(() => {

        setSee(contacts.map(() => true));

        (async () => {
            var waitng = setTimeout(() => {
                setLoading(true)
            }, 50)
            var data = await Promise.all(contacts.map(async (name, i) => {
                if (userNames?.[name]) return userNames[name];
                var res = await fetch(api + "/name/" + name)
                userNames[name] = await res.text();
                return userNames[name]
            }))
            clearTimeout(waitng)
            setLoading(false)
            setContactNames(data)
        })()

    }, [contacts])

    return <div className="cont">
        <form className="search-form" onSubmit={async e => {
            try {
                e.preventDefault();
                var search = (inp.current.value == "" ? "`" : inp.current.value).split("/").join(" ");
                var res = await fetch(api + "/search/" + search)
                var res = (await res.text()).split("\n")
                var resArray = res[0] == "[]" ? [] : res
                log(resArray)
                setContacts(resArray)
                setNoResults(false)
                if (resArray.length == 0)
                    setNoResults(true)
            } catch (error) { }
        }}>

            <input ref={inp} type="text" placeholder="Search..." onInputCapture={e => {
                setSee(contactNames.map(c =>
                    c.toLocaleLowerCase().includes(
                        e.target.value.toLocaleLowerCase()
                    )
                ))
            }} />

            <button>
                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z" /></svg>
            </button>

        </form>
        <ul>
            {
                loading ? <LoadingSpinner /> :
                    contactNames.map((name, i) =>
                        <User key={contacts[i]} contactName={name} see={see[i]} name={contacts[i]} />
                    )
            }
            {
                noResults ? "no results" : ""
            }
        </ul>
    </div>

}