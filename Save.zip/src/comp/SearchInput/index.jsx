export var SearchInput = ({ contacts, setSee }) =>
    <input type="text" placeholder="Search..."
        onInputCapture={e => {
            const search = e.target.value.toLowerCase();
            var newSeeArray = [];
            contacts.forEach(contact => {
                newSeeArray.push(contact.toLowerCase().includes(search));
            });
            setSee(newSeeArray);
        }}
    />