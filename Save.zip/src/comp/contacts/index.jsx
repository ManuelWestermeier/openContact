import { useEffect, useState } from "react"
import "./index.css"
import { Contact } from "./contact"
import { SearchInput } from "../SearchInput/index"
import { url } from "../../App"
import LoadingSpinner from "../loading-spinner"

var originalContacts = JSON.parse(localStorage.getItem(":contacts:") || "[]")

var userNames = {}

stroreOriginalContacts()

function stroreOriginalContacts() {
    localStorage.setItem(":contacts:", JSON.stringify(originalContacts))
}

export function Contacts({ }) {

    var [contacts, setContacts] = useState(originalContacts)
    var [contactNames, setContactNames] = useState(contacts)
    var [see, setSee] = useState(contacts.map(c => true))
    var [loading, setLoading] = useState(false)

    useEffect(() => localStorage.setItem(":contacts:", JSON.stringify(contacts)), [contactNames, contacts])

    useEffect(() => {
        log("contacts change")
        setSee(contacts.map(e => true));

        (async () => {
            var waitng = setTimeout(() => {
                setLoading(true)
            }, 50)
            var data = await Promise.all(contacts.map(async (name, i) => {
                if (userNames?.[name]) return userNames[name];
                var res = await fetch(api + "/name/" + name)
                userNames[name] = await res.text();
                return userNames[name]
            }))
            clearTimeout(waitng)
            setLoading(false)
            setContactNames(data)
        })()
    }, [contacts])

    useEffect(() => {
        if (url.searchParams.get("run") == "newContact")
            if (url.searchParams.get("user"))
                if (originalContacts.indexOf(url.searchParams.get("user")) == -1) {
                    if (!contacts.includes(url.searchParams.get("user")))
                        setContacts([url.searchParams.get("user"), ...contacts])
                }
                else {
                    if (document.getElementById(url.searchParams.get("user")))
                        document.getElementById(url.searchParams.get("user"))?.scrollIntoView?.(false)
                }
    }, [contactNames])

    return <div className="cont">
        <ul>
            <SearchInput contacts={contactNames} setSee={setSee} />
            {
                loading ? <LoadingSpinner /> :
                    contactNames.map((name, i) => {
                        return <Contact key={contacts[i]} contactName={name} see={see[i]} setContacts={setContacts} cont={contacts[i]} />
                    })
            }
        </ul>
    </div>

}