import "./index.css"

export function Home({ setPage, page }) {

    return <div className="home">
        <img key={page} src="https://manuelwestermeier.github.io/openContacts/logo.jpg" alt="" />
        <h1>Contacts</h1>
    </div>

}